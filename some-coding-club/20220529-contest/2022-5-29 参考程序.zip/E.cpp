#include<bits/stdc++.h>
#define pb push_back
#define mp make_pair
using namespace std;
typedef long long ll;
const int mod = 998244353;
const int maxn = 5e5 + 233;
inline void add(ll& x,ll v){x = (x+v)%mod;}
ll f[maxn],g[maxn];
int a[maxn];
int main(){
	int n;cin>>n;
	for(int i=1;i<=n;i++)scanf("%d",&a[i]);
	ll ans = 2e18;
	f[0] = g[0] = 0;
	f[1] = g[1] = a[1];
	f[2] = a[1] + a[2];
	g[2] = a[1];
	for(int i=3;i<=n;i++){
		f[i] = min(f[i-1],g[i-1])+a[i];
		g[i] = f[i-1];
	}
	ans = min(ans,min(g[n],f[n]));
	
	f[1] = g[1] = 0;
	f[2] = g[2] = a[2];
	for(int i=3;i<=n;i++){
		f[i] = min(f[i-1],g[i-1])+a[i];
		g[i] = f[i-1];
	}
	ans = min(ans,f[n]);
	
	cout << ans << endl;
}

