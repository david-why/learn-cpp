#include<bits/stdc++.h>
#define pb push_back
#define mp make_pair
using namespace std;
typedef long long ll;
const int mod = 998244353;
const int maxn = 3000 + 233;
inline void add(ll& x,ll v){x = (x+v)%mod;}
ll dp[3010][3010];
int a[maxn],b[maxn];
int main(){
	int n;cin>>n;
	for(int i=1;i<=n;i++)scanf("%d",&a[i]);
	for(int i=1;i<=n;i++)scanf("%d",&b[i]);
	
	dp[0][0] = 1;
	for(int i=1;i<=n;i++){
		ll sum = 0;
		for(int j=0;j<=3000;j++){
			add(sum,dp[i-1][j]);
			if(a[i] <= j && j <= b[i])
				dp[i][j] = sum;
		}
	}
	ll ans = 0;
	for(int j=0;j<=3000;j++)add(ans,dp[n][j]);
	cout << ans << endl;
}

