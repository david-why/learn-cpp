#include<bits/stdc++.h>
#define pb push_back
#define mp make_pair
using namespace std;
typedef long long ll;
const int mod = 998244353;
const int maxn = 233;
inline void add(ll& x,ll v){x = (x+v)%mod;}
int cnt[30];
bool edge[30][30],vis[30],ok;
vector<int> g[30];
char s[maxn];
vector<vector<int> > ans;
vector<int> tmp;
void dfs(int x,int fa){
	vis[x] = 1;
	tmp.pb(x);
	for(int y:g[x]){
		if(y == fa)continue;
		if(vis[y]){
			ok = 0;//����ߣ��л�
			continue;
		}
		dfs(y,x); 
	}
}
bool cmp(const vector<int> &A,const vector<int> &B){
	return A[0] < B[0];
}
int main(){
	int T;cin>>T;
	while(T--){
		scanf("%s",s+1);
		int n = strlen(s+1);
		memset(edge,0,sizeof(edge));
		memset(vis,0,sizeof(vis));
		memset(cnt,0,sizeof(cnt));
		for(int i=0;i<26;i++){
			g[i].clear();
		}
		for(int i=1;i<n;i++){
			int x = s[i] - 'a',y = s[i+1] - 'a';
			if(edge[x][y])continue;
			edge[x][y] = edge[y][x] = 1;
			g[x].pb(y);g[y].pb(x);
		}
		ok = 1;
		for(int i=0;i<26;i++)
			if(g[i].size() >= 3)
				ok = 0;
		ans.clear();
		int tot = 0;
		for(int i=0;i<26;i++){
			if(vis[i])continue;
			if(g[i].size() == 2)continue;
			tmp.clear();
			dfs(i,-1);
			if(tmp[0] > tmp.back())
				reverse(tmp.begin(),tmp.end());
			ans.pb(tmp);
			tot += tmp.size();
		}
		if(tot < 26) ok = 0;
		if(!ok){
			puts("NO");
			continue;
		}
		puts("YES");
		sort(ans.begin(),ans.end(),cmp);
		for(auto v:ans)for(int x:v)printf("%c",'a'+x);
		puts("");
	}
}

