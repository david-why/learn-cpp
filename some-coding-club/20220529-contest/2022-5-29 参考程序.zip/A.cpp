#include<bits/stdc++.h>
#define pb push_back
#define mp make_pair
using namespace std;
typedef long long ll;
const int mod = 998244353;
const int maxn = 100 + 233;
inline void add(ll& x,ll v){x = (x+v)%mod;}
char s[maxn][10];
int p[maxn][10];
int cnt[10];
int main(){
	int n;cin>>n;
	for(int i=1;i<=n;i++){
		scanf("%s",s[i]);
		for(int j=0;j<10;j++)
			p[i][s[i][j]-'0'] = j;
		
//		for(int j=0;j<10;j++)cout << p[i][j] << " ";cout << endl;
	}
	int ans = 1e9;
	for(int c=0;c<=9;c++){
		memset(cnt,0,sizeof(cnt));
		int tmp = 0;
		for(int i=1;i<=n;i++){
			int pos = p[i][c];
			tmp = max(tmp,cnt[pos]*10 + pos);
			cnt[pos]++;
		}
//		cout << c << ": " << tmp << endl;
		ans = min(ans,tmp);
	}
	cout << ans << endl;
}

