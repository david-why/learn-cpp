#include<bits/stdc++.h>
#define pb push_back
#define mp make_pair
using namespace std;
typedef long long ll;
const int mod = 998244353;
const int maxn = 3000 + 233;
int n,P;
inline void add(ll& x,ll v){x = (x+v)%P;}
ll dp[3030][3030],sum[3030][3030];
inline ll get_sum(int l,int r,int j){
	if(j < 0)return 0;
	if(r < 0)return 0;
	ll res;
	if(l <= 0)res =  sum[r][j];
	else res = (sum[r][j] - sum[l-1][j] + P) % P;
	if(j == 0)return res * 26 % P;
	else return res * 25 % P;
}
int main(){
	cin>>n>>P;
	dp[0][0] = 1;
	for(int i=0;i<=3000;i++)sum[i][0] = 1;
	for(int j=1;j<=3000;j++){
		for(int i=1;i<=3000;i++){
			//����dp[i][j] 
			dp[i][j] = (get_sum(i-9,i-1,j-2) + get_sum(i-99,i-10,j-3) +
				 get_sum(i-999,i-100,j-4) + get_sum(i-3000,i-1000,j-5)) % P;
			sum[i][j] = (sum[i-1][j] + dp[i][j]) % P; 
		}
	}
	ll ans = 0;
	for(int j=0;j<n;j++)add(ans,dp[n][j]);
	cout << ans << endl;
}

