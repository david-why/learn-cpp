#include<bits/stdc++.h>
#define pb push_back
#define mp make_pair
using namespace std;
typedef long long ll;
const int mod = 998244353;
const int maxn = 5e5 + 233;
inline void add(ll& x,ll v){x = (x+v)%mod;}
int ans[maxn],vis[maxn];
vector<vector<int> > a[2];
vector<int> g[maxn],X,Y;
bitset<5010> dp[5010];
void dfs(int x,int flag){
	if(vis[x] == -1){
		vis[x] = flag;
		if(flag == 0)X.pb(x);
		else Y.pb(x);
	}
	else {
		if(vis[x] != flag){//���滷�����Ƕ���ͼ 
			puts("NO");
			exit(0);
		}
		return;
	}
	for(int y:g[x])dfs(y,flag^1);
}
int n,m;int n1,n2,n3;
inline void work2(vector<int> &V){
	for(int x:V)ans[x] = 2;
}
inline void work13(vector<int> &V){
	for(int x:V){
		if(n1){
			ans[x] = 1;
			n1--;
		}
		else{
			ans[x] = 3;
		}
	}
}
int main(){
	cin>>n>>m;
	cin>>n1>>n2>>n3;
	for(int i=1;i<=m;i++){
		int x,y;scanf("%d%d",&x,&y);
		g[x].pb(y);
		g[y].pb(x);
	}
	memset(vis,-1,sizeof(vis));
	for(int i=1;i<=n;i++){
		X.clear();Y.clear();
		if(vis[i] != -1)continue;
		dfs(i,0);
		a[0].pb(X),a[1].pb(Y);
//		cout << "X: "; for(int x:X)cout << x << " ";cout << endl;
//		cout << "Y: "; for(int x:Y)cout << x << " ";cout << endl;
	}
	int m = a[0].size();
	dp[0].reset();dp[0][0] = 1;
	for(int i=1;i<=m;i++){
		int x = a[0][i-1].size(),y = a[1][i-1].size();
		dp[i] = (dp[i-1] << x) | (dp[i-1] << y);
	}
	if(dp[m][n2])puts("YES");
	else{
		puts("NO");
		return 0;
	}
	int cur = n2;
	for(int i=m;i>=1;i--){
		int x = a[0][i-1].size(),y = a[1][i-1].size();
		if(cur >= x && dp[i-1][cur-x]){
			cur -= x;
			work2(a[0][i-1]);
			work13(a[1][i-1]);
		}
		else{
			cur -= y;
			work13(a[0][i-1]);
			work2(a[1][i-1]);
		}
	}
	for(int i=1;i<=n;i++)putchar('0'+ans[i]);
}
/*
6 3
2 4 0
3 1
5 4
2 5
*/
